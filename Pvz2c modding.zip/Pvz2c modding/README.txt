Made by LuvTime
Youtube channel: www.youtube.com/@Lvvu125
Github: https://github.com/Luvtime125
Discord server: https://discord.com/invite/wawqSX73wg



this tool can help you to modding pvz2 Chinese 

like plants 0 cost or plants max level and more....

-to modding pvz2 Chinese 

1. go to /storage/emulated/0/Android/data/com.popcap.pvz2cthd360/files/ 
   and copy dynamic.rsb.smf into your pc 
2. rename dynamic.rsb.smf to dynamic.rsb.smf.rsb and use seen tool with option
   60. PopCap RSB: Unpack
3. try to find Packages.rsg
   and drag Packages.rsg to sen tool for unpack it and go copy any rton file 
   and drag it into sen tool and use option 65. PopCap RTON: Decrypt & Decode
4. use JsonFixer to fix json and view code to be simple for edit
5. drag your json into sen tool and use option  67. PopCap RTON: Encode & Encrypt
6. pack Packages.packet
7. copy it to dynamic.rsb.smf.rsb.bundle / packet
8. pack dynamic.rsb.smf.rsb.bundle and rename from dynamic.rsb.smf.rsb to dynamic.rsb.smf
9. copy dynamic.rsb.smf to game files is /storage/emulated/0/Android/data/com.popcap.pvz2cthd360/files/

10. and done